"""Configuração local pronta do agente da balança Bliss Açaiteria."""

URL_PDV = "https://bliss-acaiteria.wpnz.com.br"
TOKEN = "bliss-scale-70c2d3ca806d6b40f4765b67539f03992601a4a8e9bebc63"

# USB-SERIAL CH340 (COM4), conforme conferido no computador do caixa.
PORTA = "COM4"
VELOCIDADE = 9600
UNIDADE = "auto"
FLUXO_HARDWARE = False

CAPACIDADE_MAXIMA_KG = 32.0
PESO_MINIMO = 0.010
VARIACAO_MINIMA = 0.005
LEITURAS_ESTAVEIS = 3
REENVIO_SEGUNDOS = 30
